# this is my api key (secret)
key = "AIzaSyAeVpnX-VpUFh_V1NMYWmaLQ81YMErZbvA"